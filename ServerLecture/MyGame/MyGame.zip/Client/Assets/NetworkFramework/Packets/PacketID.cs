﻿namespace Packets
{
    public enum PacketID
    {
        C_LogInPacket,
        S_LogInPacket,
        C_RoomEnterPacket,
        S_RoomEnterPacket,
        S_PlayerJoinPacket,
        S_MovePacket,
        C_MovePacket
    }
}